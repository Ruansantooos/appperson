
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Card, Badge, ButtonCircle } from '../components/ui/LayoutComponents';
import { 
  Plus, 
  Search, 
  MoreHorizontal, 
  Link as LinkIcon, 
  Network,
  Maximize2,
  ChevronRight,
  Hash,
  Clock
} from 'lucide-react';
import { MOCK_PROJECTS, GRAPH_DATA } from '../lib/mock-data';
import { GraphNode } from '../types';

// Configurações da simulação de física
const PHYSICS = {
  repulsion: 4000,     // Força de repulsão entre nós
  centerGravity: 0.05, // Força que puxa para o centro
  linkDistance: 120,   // Distância ideal entre links
  linkStrength: 0.04,  // Força da mola dos links
  friction: 0.85,      // Perda de energia (0-1)
};

const ProjectsPage: React.FC = () => {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [nodes, setNodes] = useState<GraphNode[]>(GRAPH_DATA.nodes);
  const [draggedNode, setDraggedNode] = useState<string | null>(null);
  
  const svgRef = useRef<SVGSVGElement>(null);
  const requestRef = useRef<number>(null);
  const velocities = useRef<Map<string, { vx: number, vy: number }>>(new Map());

  // Inicializa velocidades
  useEffect(() => {
    nodes.forEach(node => {
      velocities.current.set(node.id, { vx: (Math.random() - 0.5) * 2, vy: (Math.random() - 0.5) * 2 });
    });
  }, []);

  // Loop de Simulação de Física
  const updatePhysics = () => {
    setNodes(currentNodes => {
      const nextNodes = currentNodes.map(node => ({ ...node }));
      
      nextNodes.forEach((node, i) => {
        if (node.id === draggedNode) return;

        let { vx, vy } = velocities.current.get(node.id) || { vx: 0, vy: 0 };

        // 1. Gravidade Central
        vx += (400 - node.x) * PHYSICS.centerGravity;
        vy += (300 - node.y) * PHYSICS.centerGravity;

        // 2. Repulsão entre nós (Lei de Coulomb simplificada)
        nextNodes.forEach((other, j) => {
          if (i === j) return;
          const dx = node.x - other.x;
          const dy = node.y - other.y;
          const distSq = dx * dx + dy * dy + 0.1;
          const force = PHYSICS.repulsion / distSq;
          vx += (dx / Math.sqrt(distSq)) * force;
          vy += (dy / Math.sqrt(distSq)) * force;
        });

        // 3. Força de Link (Molas)
        GRAPH_DATA.links.forEach(link => {
          if (link.source === node.id || link.target === node.id) {
            const targetId = link.source === node.id ? link.target : link.source;
            const targetNode = nextNodes.find(n => n.id === targetId);
            if (targetNode) {
              const dx = targetNode.x - node.x;
              const dy = targetNode.y - node.y;
              const dist = Math.sqrt(dx * dx + dy * dy) || 1;
              const diff = (dist - PHYSICS.linkDistance) / dist;
              vx += dx * diff * PHYSICS.linkStrength;
              vy += dy * diff * PHYSICS.linkStrength;
            }
          }
        });

        // Aplicar fricção e atualizar posição
        vx *= PHYSICS.friction;
        vy *= PHYSICS.friction;
        
        node.x += vx;
        node.y += vy;
        
        velocities.current.set(node.id, { vx, vy });
      });

      return nextNodes;
    });

    requestRef.current = requestAnimationFrame(updatePhysics);
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(updatePhysics);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [draggedNode]);

  // Handlers de Arraste
  const handleMouseDown = (nodeId: string) => {
    setDraggedNode(nodeId);
    setSelectedNode(nodeId);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (draggedNode && svgRef.current) {
      const CTM = svgRef.current.getScreenCTM();
      if (CTM) {
        const x = (e.clientX - CTM.e) / CTM.a;
        const y = (e.clientY - CTM.f) / CTM.d;
        setNodes(prev => prev.map(n => n.id === draggedNode ? { ...n, x, y } : n));
        velocities.current.set(draggedNode, { vx: 0, vy: 0 });
      }
    }
  };

  const handleMouseUp = () => setDraggedNode(null);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'success';
      case 'Slowburn': return 'warning';
      case 'Idle': return 'status';
      default: return 'default';
    }
  };

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col xl:flex-row gap-6 select-none" onMouseUp={handleMouseUp} onMouseMove={handleMouseMove}>
      {/* Sidebar de Projetos */}
      <div className="w-full xl:w-80 flex flex-col gap-4 overflow-y-auto pr-2 custom-scrollbar">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-bold uppercase tracking-[0.2em] text-white/30">Main Maps</h3>
          <ButtonCircle icon={<Plus size={16} />} className="w-8 h-8" />
        </div>
        
        <div className="relative mb-4">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20" />
          <input 
            type="text" 
            placeholder="Search projects..." 
            className="w-full h-10 bg-white/5 border border-white/5 rounded-lg pl-10 text-xs text-white placeholder:text-white/20 focus:outline-none focus:border-[#c1ff72]/40"
          />
        </div>

        <div className="space-y-3">
          {MOCK_PROJECTS.map(project => (
            <div 
              key={project.id} 
              className={`p-4 rounded-xl border border-white/5 cursor-pointer transition-all group ${selectedNode === project.id ? 'bg-[#c1ff72]/5 border-[#c1ff72]/30 scale-[1.02]' : 'bg-[#161616] hover:bg-white/[0.03]'}`}
              onClick={() => setSelectedNode(project.id)}
            >
              <div className="flex justify-between items-start mb-2">
                <h4 className={`text-sm font-bold ${selectedNode === project.id ? 'text-[#c1ff72]' : 'text-white'}`}>{project.name}</h4>
                <Badge variant={getStatusColor(project.status) as any}>{project.status}</Badge>
              </div>
              <div className="flex flex-wrap gap-2 mb-3">
                {project.tags.map(tag => (
                  <span key={tag} className="text-[9px] font-bold text-blue-400 opacity-60 group-hover:opacity-100">{tag}</span>
                ))}
              </div>
              <div className="flex items-center justify-between mt-auto">
                <span className="text-[9px] text-white/20 font-medium uppercase flex items-center gap-1">
                  <Clock size={10} /> {project.lastEdited}
                </span>
                {project.links.length > 0 && (
                  <span className="text-[9px] text-[#c1ff72] font-bold flex items-center gap-1 uppercase">
                    <LinkIcon size={10} /> {project.links.length}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 space-y-4">
           <p className="text-[10px] font-bold text-white/10 uppercase tracking-[0.2em]">Quick Links</p>
           {['#question', '#state/develop', '#project/active'].map(tag => (
             <div key={tag} className="flex items-center justify-between text-xs text-white/40 hover:text-white cursor-pointer group">
               <span className="flex items-center gap-2"><Hash size={12} className="text-[#c1ff72]" /> {tag}</span>
               <ChevronRight size={12} className="opacity-0 group-hover:opacity-100" />
             </div>
           ))}
        </div>
      </div>

      {/* Dynamic Knowledge Graph */}
      <div className="flex-1 min-h-[500px] xl:min-h-full">
        <Card className="h-full relative overflow-hidden bg-[#0c0c0c] border-white/5">
          <div className="absolute top-6 left-6 z-10 pointer-events-none">
            <h3 className="text-xl font-bold tracking-tighter flex items-center gap-3">
               Graph of <span className="text-[#c1ff72]">+Home</span>
               <Network size={20} className="text-white/10" />
            </h3>
            <p className="text-[9px] text-white/20 font-bold uppercase tracking-widest mt-1">Simulação de Campo de Força Ativa</p>
          </div>
          
          <div className="absolute top-6 right-6 z-10 flex gap-2">
            <button className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white/40 hover:text-white hover:bg-white/10 transition-all border border-white/5">
              <Maximize2 size={16} />
            </button>
            <button className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white/40 hover:text-white hover:bg-white/10 transition-all border border-white/5">
              <MoreHorizontal size={16} />
            </button>
          </div>

          <svg 
            ref={svgRef}
            width="100%" height="100%" 
            viewBox="0 0 800 600" 
            className="w-full h-full cursor-crosshair"
          >
            {/* Links Elásticos */}
            <g className="links">
              {GRAPH_DATA.links.map((link, i) => {
                const source = nodes.find(n => n.id === link.source);
                const target = nodes.find(n => n.id === link.target);
                if (!source || !target) return null;
                
                const isActive = selectedNode === link.source || selectedNode === link.target;
                return (
                  <line 
                    key={i} 
                    x1={source.x} y1={source.y} 
                    x2={target.x} y2={target.y} 
                    stroke={isActive ? '#c1ff72' : 'white'} 
                    strokeWidth={isActive ? 1.5 : 0.2} 
                    strokeOpacity={isActive ? 0.6 : 0.1} 
                    className="transition-colors duration-300"
                  />
                );
              })}
            </g>

            {/* Nós Draggable */}
            <g className="nodes">
              {nodes.map(node => {
                const isActive = selectedNode === node.id;
                const isConnected = GRAPH_DATA.links.some(l => (l.source === node.id && l.target === selectedNode) || (l.target === node.id && l.source === selectedNode));
                const nodeSize = node.type === 'root' ? 12 : node.type === 'project' ? 8 : 4;
                
                return (
                  <g 
                    key={node.id} 
                    className="cursor-grab active:cursor-grabbing group"
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      handleMouseDown(node.id);
                    }}
                  >
                    {/* Glow effect */}
                    {(isActive || isConnected) && (
                      <circle cx={node.x} cy={node.y} r={nodeSize + 15} fill="#c1ff72" fillOpacity="0.05" />
                    )}
                    
                    <circle 
                      cx={node.x} cy={node.y} 
                      r={nodeSize} 
                      fill={isActive ? '#c1ff72' : isConnected ? '#c1ff72' : 'white'} 
                      fillOpacity={isActive || isConnected ? 1 : node.type === 'task' ? 0.2 : 0.5}
                      className="transition-all duration-300"
                    />
                    
                    {/* Label */}
                    {(nodeSize > 6 || isActive || isConnected) && (
                      <text 
                        x={node.x} y={node.y + (nodeSize + 12)} 
                        textAnchor="middle" 
                        className={`text-[9px] font-bold pointer-events-none uppercase tracking-widest transition-all ${isActive ? 'fill-[#c1ff72]' : isConnected ? 'fill-white/60' : 'fill-white/20'}`}
                      >
                        {node.label}
                      </text>
                    )}
                  </g>
                );
              })}
            </g>
          </svg>

          <div className="absolute bottom-6 left-6 right-6 flex justify-between items-center pointer-events-none">
             <div className="flex gap-4">
               <div className="flex items-center gap-2">
                 <div className="w-1.5 h-1.5 rounded-full bg-white opacity-40"></div>
                 <span className="text-[9px] font-bold text-white/20 uppercase tracking-widest">Inativo</span>
               </div>
               <div className="flex items-center gap-2">
                 <div className="w-1.5 h-1.5 rounded-full bg-[#c1ff72]"></div>
                 <span className="text-[9px] font-bold text-white/20 uppercase tracking-widest">Conectado</span>
               </div>
             </div>
             <p className="text-[9px] font-bold text-white/10 uppercase tracking-[0.4em]">Nexus Dynamic Engine v2.0</p>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default ProjectsPage;
