
import React from 'react';
import { Card, Button, Input, Badge, ButtonCircle } from '../components/ui/LayoutComponents';
import { User, Bell, Shield, Smartphone, Globe, CreditCard, ChevronRight, Camera, LogOut } from 'lucide-react';

const SettingsPage: React.FC = () => {
  return (
    <div className="space-y-8 pb-10">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Navigation Sidebar */}
        <div className="lg:col-span-3">
          <Card className="p-4 bg-white/[0.02] border-white/5 space-y-2">
            {[
              { label: 'Perfil', icon: User, active: true },
              { label: 'Notificações', icon: Bell },
              { label: 'Segurança', icon: Shield },
              { label: 'Integrações', icon: Smartphone },
              { label: 'Preferências', icon: Globe },
              { label: 'Faturamento', icon: CreditCard },
            ].map(item => (
              <button
                key={item.label}
                className={`w-full flex items-center justify-between px-6 py-4 rounded-2xl text-xs font-bold uppercase tracking-widest transition-all ${
                  item.active 
                    ? 'bg-[#c1ff72] text-black shadow-[0_0_15px_rgba(193,255,114,0.2)]' 
                    : 'text-white/40 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-4">
                  <item.icon size={18} />
                  {item.label}
                </div>
                {item.active && <ChevronRight size={14} />}
              </button>
            ))}
            <div className="pt-4 border-t border-white/5 mt-4">
               <button className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-xs font-bold uppercase tracking-widest text-red-500 hover:bg-red-500/10 transition-colors">
                  <LogOut size={18} /> Sair da conta
               </button>
            </div>
          </Card>
        </div>

        {/* Content Area */}
        <div className="lg:col-span-9 space-y-6">
          <Card className="p-10">
            <h3 className="text-2xl font-bold mb-10">Configurações de Perfil</h3>
            
            <div className="flex flex-col sm:flex-row items-center gap-10 mb-12">
              <div className="relative group">
                <img 
                  src="https://picsum.photos/seed/kraya/120/120" 
                  alt="Avatar" 
                  className="w-32 h-32 rounded-[40px] border-4 border-white/5 shadow-2xl"
                />
                <button className="absolute -bottom-2 -right-2 bg-[#c1ff72] p-3 rounded-full text-black shadow-xl hover:scale-110 transition-transform">
                  <Camera size={20} />
                </button>
              </div>
              <div className="text-center sm:text-left">
                <h4 className="text-2xl font-bold">John Doe</h4>
                <p className="text-sm text-white/30 mt-1 uppercase tracking-widest font-bold">Membro Pro desde 2023</p>
                <div className="flex gap-2 mt-4 justify-center sm:justify-start">
                  <Badge variant="success">Premium</Badge>
                  <Badge variant="status">Beta User</Badge>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Nome Completo</label>
                <Input defaultValue="John Doe" className="h-14 bg-[#161616] border-white/5" />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Email Principal</label>
                <Input defaultValue="johndoe@kraya.com" className="h-14 bg-[#161616] border-white/5" />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Fuso Horário</label>
                <div className="relative">
                  <select className="w-full h-14 px-6 bg-[#161616] border border-white/5 rounded-xl text-white appearance-none focus:ring-2 focus:ring-[#c1ff72] focus:outline-none transition-all">
                    <option>Brasília (UTC-3)</option>
                    <option>Nova York (UTC-5)</option>
                    <option>Londres (UTC+0)</option>
                  </select>
                  <ChevronRight size={18} className="absolute right-6 top-1/2 -translate-y-1/2 rotate-90 text-white/20 pointer-events-none" />
                </div>
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Telefone</label>
                <Input defaultValue="+55 11 99999-8888" className="h-14 bg-[#161616] border-white/5" />
              </div>
            </div>
            
            <div className="mt-12 flex justify-end gap-4">
              <Button variant="outline" className="h-12 border-white/10 hover:bg-white/5">Descartar</Button>
              <Button className="h-12 px-10">Salvar Alterações</Button>
            </div>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="p-8 border-red-500/10 bg-red-500/[0.02]">
              <h3 className="text-lg font-bold text-red-400 mb-2">Zona Crítica</h3>
              <p className="text-xs text-white/30 mb-8 leading-relaxed font-bold uppercase tracking-widest">Remover sua conta irá deletar permanentemente todos os seus dados e históricos do Nexus.</p>
              <Button variant="danger" className="w-full h-12 bg-red-600/20 text-red-500 border border-red-500/20 hover:bg-red-500 hover:text-white">
                 Deletar Minha Conta
              </Button>
            </Card>
            <Card variant="blue" className="p-8">
               <h3 className="text-lg font-bold mb-4">Nexus Cloud</h3>
               <p className="text-xs font-bold opacity-60 uppercase tracking-widest leading-relaxed mb-6">Backup automático ativado. Seus dados estão sincronizados com segurança.</p>
               <div className="flex items-center justify-between bg-black/10 px-6 py-4 rounded-2xl">
                  <span className="text-xs font-bold uppercase tracking-widest">Último backup</span>
                  <span className="text-xs font-bold">Há 2 horas</span>
               </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
