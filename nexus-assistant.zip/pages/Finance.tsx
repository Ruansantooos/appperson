
import React from 'react';
import { Card, Badge, Button, ButtonCircle } from '../components/ui/LayoutComponents';
import { 
  Plus, 
  ArrowUpRight, 
  ArrowDownLeft, 
  TrendingUp,
  Download,
  MoreHorizontal
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell 
} from 'recharts';
import { MOCK_TRANSACTIONS } from '../lib/mock-data';

const categoryData = [
  { name: 'Comida', value: 400, color: '#d8b4a6' },
  { name: 'Aluguel', value: 1200, color: '#8fb0bc' },
  { name: 'Compras', value: 300, color: '#c1ff72' },
  { name: 'Utils', value: 200, color: '#e6a06e' },
  { name: 'Lazer', value: 150, color: '#ffffff' },
];

const FinancePage: React.FC = () => {
  return (
    <div className="space-y-8 pb-10">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card variant="peach" className="p-6 relative">
             <div className="absolute top-4 right-4 bg-black/10 p-1.5 rounded-full">
               <ArrowUpRight size={14} />
             </div>
             <p className="text-xs font-bold opacity-60 uppercase tracking-widest">Saldo Total</p>
             <h4 className="text-2xl font-bold mt-2">R$ 12.450</h4>
        </Card>
        <Card variant="blue" className="p-6 relative">
             <div className="absolute top-4 right-4 bg-black/10 p-1.5 rounded-full">
               <TrendingUp size={14} />
             </div>
             <p className="text-xs font-bold opacity-60 uppercase tracking-widest">Receitas (Mês)</p>
             <h4 className="text-2xl font-bold mt-2">R$ 5.200</h4>
        </Card>
        <Card variant="orange" className="p-6 relative">
             <div className="absolute top-4 right-4 bg-black/10 p-1.5 rounded-full">
               <ArrowDownLeft size={14} />
             </div>
             <p className="text-xs font-bold opacity-60 uppercase tracking-widest">Despesas (Mês)</p>
             <h4 className="text-2xl font-bold mt-2">R$ 2.847</h4>
        </Card>
        <Card className="p-6 relative bg-white/5 border-white/10 flex items-center justify-center">
             <Button className="w-full h-full bg-[#c1ff72] text-black">
                <Plus size={20} /> Nova Transação
             </Button>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Expenses by Category Chart */}
        <div className="lg:col-span-4">
          <Card className="p-8 h-full">
            <h3 className="text-lg font-medium text-white/60 mb-8">Gastos por Categoria</h3>
            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryData} layout="vertical" margin={{ left: -20 }}>
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{fill: '#444', fontSize: 10}} />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={12}>
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-6 space-y-4">
              {categoryData.map(cat => (
                <div key={cat.name} className="flex items-center justify-between text-xs font-bold uppercase tracking-wider">
                  <div className="flex items-center gap-3 text-white/40">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: cat.color }}></span>
                    {cat.name}
                  </div>
                  <span className="text-white">R$ {cat.value}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Recent Transactions List */}
        <div className="lg:col-span-8">
          <Card className="p-8">
            <div className="flex justify-between items-center mb-10">
              <h3 className="text-xl font-bold">Transações Recentes</h3>
              <div className="flex gap-2">
                <button className="bg-white/5 border border-white/10 px-6 py-2 rounded-full text-xs font-bold flex items-center gap-2 hover:bg-white/10 transition-colors">
                  <Download size={14} /> Exportar
                </button>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-white/30 text-[10px] uppercase tracking-[0.2em] border-b border-white/5 pb-4">
                    <th className="pb-4 font-medium">Data</th>
                    <th className="pb-4 font-medium">Descrição</th>
                    <th className="pb-4 font-medium">Categoria</th>
                    <th className="pb-4 font-medium text-right">Valor</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {MOCK_TRANSACTIONS.slice(0, 8).map(tx => (
                    <tr key={tx.id} className="group border-b border-white/5 last:border-0 hover:bg-white/[0.02] transition-colors">
                      <td className="py-6 text-white/40 font-medium">{tx.date}</td>
                      <td className="py-6 font-bold">{tx.description}</td>
                      <td className="py-6">
                        <Badge variant="status">{tx.category}</Badge>
                      </td>
                      <td className={`py-6 text-right font-bold ${tx.type === 'income' ? 'text-[#c1ff72]' : 'text-white'}`}>
                        {tx.type === 'income' ? '+' : '-'} R$ {tx.amount.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Button variant="outline" className="w-full mt-8 border-white/5">Ver histórico completo</Button>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default FinancePage;
