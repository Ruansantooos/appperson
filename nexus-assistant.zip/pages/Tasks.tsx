
import React, { useState } from 'react';
import { Card, Badge, Button, Input, ButtonCircle } from '../components/ui/LayoutComponents';
// Added MoreHorizontal to imports
import { Plus, Search, Filter, MoreVertical, MoreHorizontal, Calendar, CheckCircle2, Circle, ArrowUpRight } from 'lucide-react';
import { MOCK_TASKS } from '../lib/mock-data';
import { Task } from '../types';

const TasksPage: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>(MOCK_TASKS);
  const [filter, setFilter] = useState('All');

  const filteredTasks = tasks.filter(t => {
    if (filter === 'All') return true;
    if (filter === 'Completed') return t.status === 'Completed';
    if (filter === 'Pending') return t.status === 'Pending';
    return true;
  });

  const toggleTask = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, status: t.status === 'Completed' ? 'Pending' : 'Completed' } : t));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative flex-1 md:w-80">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
            <Input className="pl-12 h-12 rounded-full border-white/5 bg-[#161616]" placeholder="Buscar tarefas..." />
          </div>
          <Button variant="outline" className="h-12 w-12 p-0 flex items-center justify-center">
             <Filter size={18} />
          </Button>
        </div>
        <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
          {['All', 'Pending', 'Completed'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-6 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition-all whitespace-nowrap ${
                filter === f ? 'bg-[#c1ff72] text-black' : 'bg-white/5 text-white/40 hover:bg-white/10'
              }`}
            >
              {f}
            </button>
          ))}
          <Button className="h-10 ml-2 shadow-[0_0_15px_rgba(193,255,114,0.2)]">
            <Plus size={16} /> Nova
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTasks.map(task => (
          <Card key={task.id} className="p-6 group relative">
            <div className="flex items-start gap-4">
              <button 
                onClick={() => toggleTask(task.id)}
                className={`mt-1 flex-shrink-0 transition-colors ${task.status === 'Completed' ? 'text-[#c1ff72]' : 'text-white/20 hover:text-white/40'}`}
              >
                {task.status === 'Completed' ? <CheckCircle2 size={24} /> : <Circle size={24} />}
              </button>
              
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-start">
                  <div className="min-w-0">
                    <h3 className={`text-base font-bold truncate ${task.status === 'Completed' ? 'line-through text-white/20' : 'text-white'}`}>
                      {task.title}
                    </h3>
                    <div className="flex flex-wrap items-center gap-2 mt-3">
                      <Badge variant={task.priority === 'High' ? 'danger' : task.priority === 'Medium' ? 'warning' : 'default'}>
                        {task.priority}
                      </Badge>
                      <span className="text-[10px] text-white/30 flex items-center gap-1 font-bold uppercase tracking-widest">
                        <Calendar size={12} /> {task.dueDate}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
               <button className="text-white/20 hover:text-white"><MoreHorizontal size={20} /></button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default TasksPage;
