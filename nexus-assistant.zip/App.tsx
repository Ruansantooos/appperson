
import React from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Sidebar from './components/shared/Sidebar';
import Header from './components/shared/Header';
import MobileNav from './components/shared/MobileNav';

// Pages
import Dashboard from './pages/Dashboard';
import TasksPage from './pages/Tasks';
import ProjectsPage from './pages/Projects'; // Nova página
import FinancePage from './pages/Finance';
import HabitsPage from './pages/Habits';
import CalendarPage from './pages/Calendar';
import SettingsPage from './pages/Settings';
import GymPage from './pages/Gym';

const AppContent: React.FC = () => {
  const location = useLocation();

  return (
    <div className="flex min-h-screen bg-[#0c0c0c] text-white overflow-x-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col min-w-0">
        <Header />
        
        <div className="flex-1 px-4 lg:px-10 max-w-[1600px] w-full mx-auto pt-2 pb-24 lg:pb-10">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/tasks" element={<TasksPage />} />
            <Route path="/projects" element={<ProjectsPage />} />
            <Route path="/finance" element={<FinancePage />} />
            <Route path="/habits" element={<HabitsPage />} />
            <Route path="/calendar" element={<CalendarPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/gym" element={<GymPage />} />
            <Route path="*" element={<Dashboard />} />
          </Routes>
        </div>
      </main>

      <MobileNav />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <Router>
      <AppContent />
    </Router>
  );
};

export default App;
